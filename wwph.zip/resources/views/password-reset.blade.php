<style>
    body {
        font-family: Arial, Helvetica, sans-serif;
    }
</style>

<p>{{ $data['body'] }}</p>
<p>
    <strong>{{ $data['token'] }}</strong>
</p>

<p>
    Thank you,
</p>

